import pandas as pd
from io import StringIO
from .ai_local import get_llm_response

def load_and_validate_csv(csv_content):
    return pd.read_csv(StringIO(csv_content))

def get_trekking_logistics(destination, days, cost_pref):
    """Calculates all logistics in INR and provides Trekking data."""
    logistics = {
        "Himalayas, Nepal": {"temp": "-8°C", "cal": 4800, "inr_rate": 6500},
        "Zermatt, Switzerland": {"temp": "-3°C", "cal": 4200, "inr_rate": 35000},
        "Jyotirlinga Circuit, India": {"temp": "26°C", "cal": 2200, "inr_rate": 3800}
    }
    
    data = logistics.get(destination, {"temp": "15°C", "cal": 2500, "inr_rate": 5000})
    multiplier = {"Budget": 0.7, "Moderate": 1.0, "Luxury": 2.8}.get(cost_pref, 1.0)
    total_inr = int(data['inr_rate'] * int(days) * multiplier)
    
    return data['temp'], f"INR {total_inr:,}", data['cal']

def generate_full_plan(llm_pipeline, client_row, temp_val):
    dest = client_row['destination']
    days = client_row['duration_days']
    weather, budget_inr, daily_cal = get_trekking_logistics(dest, days, client_row.get('cost_preference', 'Moderate'))
    
    # Gear & Language logic
    gear = "Standard Gear"
    phrases = ""
    if "Himalayas" in dest:
        gear = "Heavy Woolen Sweaters, Trekking Sticks, Thermal Layers, Waterproof Boots"
        phrases = "Tashi Delek (Hello), Thuchi-che (Thank you), Zhimbu du (Delicious)"

    summary = (
        f"DESTINATION: {dest} | DURATION: {days} Days\n"
        f"ENERGY NEEDS: ~{daily_cal} Calories/Day\n"
        f"GEAR: {gear}\n"
        f"PHRASES: {phrases}\n"
        f"WEATHER: {weather} | BUDGET: {budget_inr}"
    )
    
    ai_prompt = (
        f"Create an hourly schedule for {dest}. "
        f"8:00 AM Breakfast, 10:00 AM Trek with sticks, 1:00 PM Lunch, 7:30 PM Dinner. "
        f"Include specific tea house atmosphere."
    )
    
    itinerary = get_llm_response(llm_pipeline, ai_prompt, temp=temp_val)
    return summary, itinerary, daily_cal