from transformers import pipeline

def setup_llm_pipeline():
    """Initializes the local Hugging Face model."""
    # Using t5-small for speed and local CPU performance
    return pipeline("text2text-generation", model="t5-small")

def get_llm_response(llm_pipeline, prompt, temp=0.7):
    """Executes the AI logic with the Creativity (Temperature) slider."""
    # Prefixing the prompt to help the model structure a travel plan
    enriched_prompt = f"itinerary for adventure: {prompt}"
    
    res = llm_pipeline(
        enriched_prompt, 
        max_length=1024, 
        do_sample=True, 
        temperature=float(temp),
        truncation=True
    )
    return res[0]['generated_text']