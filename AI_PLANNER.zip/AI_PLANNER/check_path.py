# check_path.py
import sys
import os

# 1. Print current search path
print("--- Current Python Search Path (sys.path) ---")
for p in sys.path:
    print(p)

# 2. Try the absolute fix manually
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = current_dir
sys.path.append(project_root)

print("\n--- After Adding Project Root ---")
print(f"Project Root Added: {project_root}")
print(f"Contents of Project Root: {os.listdir(project_root)}")

# 3. Test the import
print("\n--- Testing 'app' Import ---")
try:
    # Try importing the app module
    import app.core
    print("SUCCESS: Module 'app.core' was found and imported!")
except ModuleNotFoundError as e:
    print(f"FAILURE: ModuleNotFoundError: {e}")