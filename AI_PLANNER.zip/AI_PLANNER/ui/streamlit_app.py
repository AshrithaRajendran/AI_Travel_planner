import streamlit as st
import sys
import os
from fpdf import FPDF

# FORCE PATH RECOGNITION
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core import load_and_validate_csv, generate_full_plan, get_trekking_logistics
from app.ai_local import setup_llm_pipeline

st.set_page_config(page_title="Voyager Pro", layout="wide")

# Custom Professional Styling
st.markdown("""
    <style>
    .metric-card { background: #f0f2f6; padding: 15px; border-radius: 10px; text-align: center; border-bottom: 4px solid #007bff; }
    .metric-val { font-size: 20px; font-weight: bold; }
    .stButton>button { background-color: #007bff; color: white; border-radius: 8px; }
    </style>
    """, unsafe_allow_html=True)

def create_pdf(summary, itinerary, client_id):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(200, 10, txt=f"Voyager Pro: Adventure Guide #{client_id}", ln=True, align='C')
    pdf.ln(10)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, txt="1. Logistics & Gear Summary", ln=True)
    pdf.set_font("Arial", size=10)
    pdf.multi_cell(0, 7, txt=summary.encode('latin-1', 'replace').decode('latin-1'))
    pdf.ln(10)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, txt="2. Hourly Trekking Itinerary", ln=True)
    pdf.set_font("Arial", size=10)
    pdf.multi_cell(0, 6, txt=itinerary.encode('latin-1', 'replace').decode('latin-1'))
    return pdf.output(dest='S').encode('latin-1')

def main():
    with st.sidebar:
        st.title("🛰️ Voyager Settings")
        temp = st.slider("AI Creativity (Temperature)", 0.1, 1.0, 0.7)
        st.info("High temperature is better for Sherpa culture details.")
        st.success("🟢 AI Model: T5-Small")

    st.title("🏔️ Voyager Pro: AI Travel Assistant")
    
    @st.cache_resource
    def load_model():
        return setup_llm_pipeline()
    
    llm_pipeline = load_model()
    uploaded_file = st.file_uploader("Upload Travel.prefrence.csv", type=['csv'])

    if uploaded_file:
        df = load_and_validate_csv(uploaded_file.getvalue().decode("utf-8"))
        selected_id = st.selectbox("🎯 Select Traveler ID:", df['traveler_id'].unique())
        client = df[df['traveler_id'] == selected_id].iloc[0]

        weather, budget_inr, calories = get_trekking_logistics(client['destination'], client['duration_days'], client.get('cost_preference', 'Moderate'))

        # Display Metrics
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.markdown(f'<div class="metric-card">🆔 ID<br><span class="metric-val">{client["traveler_id"]}</span></div>', unsafe_allow_html=True)
        m2.markdown(f'<div class="metric-card">📍 Place<br><span class="metric-val">{client["destination"]}</span></div>', unsafe_allow_html=True)
        m3.markdown(f'<div class="metric-card">💰 Budget<br><span class="metric-val">{budget_inr}</span></div>', unsafe_allow_html=True)
        m4.markdown(f'<div class="metric-card">🏠 Stay<br><span class="metric-val">{client.get("hotel_style", "Local")}</span></div>', unsafe_allow_html=True)
        m5.markdown(f'<div class="metric-card">🌡️ Weather<br><span class="metric-val">{weather}</span></div>', unsafe_allow_html=True)

        if st.button("🚀 Generate Full Adventure Plan", use_container_width=True):
            with st.spinner("Analyzing high-altitude requirements..."):
                summary, itinerary, daily_cal = generate_full_plan(llm_pipeline, client, temp)
                st.session_state['itinerary'], st.session_state['summary'], st.session_state['cal'] = itinerary, summary, daily_cal

        if 'itinerary' in st.session_state:
            st.divider()
            c1, c2 = st.columns([2, 1])
            with c1:
                st.info(f"### 💡 Trekking Summary & Gear\n{st.session_state['summary']}")
            with c2:
                st.error(f"### ⚡ Daily Energy\n{st.session_state['cal']} kcal/day")

            st.markdown("### 📋 Hourly Schedule")
            st.text_area("", st.session_state['itinerary'], height=250)

            # PDF Download
            pdf_bytes = create_pdf(st.session_state['summary'], st.session_state['itinerary'], client['traveler_id'])
            st.download_button("📥 Download Itinerary (PDF)", data=pdf_bytes, file_name=f"Voyager_{client['traveler_id']}.pdf", mime="application/pdf", use_container_width=True)

if __name__ == "__main__":
    main()