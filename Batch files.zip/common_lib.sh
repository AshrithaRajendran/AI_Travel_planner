#!/usr/bin/env bash
###############################################################################
# common_lib.sh
#
# Shared library used by run_daily.sh / run_weekly.sh / run_fourweekly.sh /
# run_monthly.sh
#
# Responsibilities:
#   1. Read the OFSAA batch date from BATCH_DATE_FILE
#   2. Provide date-condition checks (Friday / last Friday / last day of month)
#   3. Provide a resumable task-runner engine:
#        - Tasks live in a master ".conf" file (one shell command per line)
#        - On first run for a given batch date, the master file is copied to
#          a per-date "run" file under the log folder for that date.
#        - The runner walks the per-date run file top to bottom, skipping
#          blank lines and lines starting with '#'.
#        - The first task that fails stops the whole script immediately.
#          The failure (and everything completed before it) is written to
#          the log file.
#        - To resume: open the per-date run file, put a '#' in front of
#          every task that is confirmed OK (already done / verified), fix
#          whatever caused the failure, then re-run the wrapper script.
#          Commented lines are skipped, execution continues from the next
#          uncommented line. The master .conf file itself is never touched,
#          so tomorrow's / next week's run always starts from a clean copy.
#        - When every line in the run file has completed successfully, a
#          SUCCESS marker is written for that date, and further runs on the
#          same date are treated as already-done (use --force to redo).
###############################################################################

set -u

# ---------------------------------------------------------------------------
# Global configuration (shared across all wrapper scripts)
# ---------------------------------------------------------------------------
BATCH_DATE_FILE="/u02/OFSAA/Scripts/Batch_date/current_batch_date.txt"
LOG_BASE_DIR="/u02/OFSAA/scripts/logs"

# ---------------------------------------------------------------------------
# Logging helper. Writes to both stdout and the run's log file (once
# LOG_FILE is set by init_run_dirs).
# ---------------------------------------------------------------------------
log() {
    local msg="$1"
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    if [[ -n "${LOG_FILE:-}" ]]; then
        echo "[$ts] $msg" | tee -a "$LOG_FILE"
    else
        echo "[$ts] $msg"
    fi
}

die() {
    log "ERROR: $1"
    exit 1
}

# ---------------------------------------------------------------------------
# Read and parse the batch date from BATCH_DATE_FILE.
# Sets global BATCH_DATE_RAW (as read from file) and BATCH_DATE (YYYY-MM-DD).
#
# NOTE ON FORMAT: this uses GNU `date -d` which understands most common
# forms out of the box: 2026-07-18 / 18-JUL-2026 / 07/18/2026 / 20260718 etc.
# If your file uses a genuinely ambiguous numeric format (e.g. 07/08/2026
# meaning 7-Aug vs Jul-8), fix the parse_batch_date() function below to
# force the correct interpretation for your site.
# ---------------------------------------------------------------------------
parse_batch_date() {
    [[ -f "$BATCH_DATE_FILE" ]] || die "Batch date file not found: $BATCH_DATE_FILE"

    BATCH_DATE_RAW=$(head -n 1 "$BATCH_DATE_FILE" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -n "$BATCH_DATE_RAW" ]] || die "Batch date file is empty: $BATCH_DATE_FILE"

    local candidate="$BATCH_DATE_RAW"

    # Handle plain YYYYMMDD explicitly (date -d sometimes mis-parses this)
    if [[ "$candidate" =~ ^[0-9]{8}$ ]]; then
        candidate="${candidate:0:4}-${candidate:4:2}-${candidate:6:2}"
    fi

    if ! BATCH_DATE=$(date -d "$candidate" +%Y-%m-%d 2>/dev/null); then
        die "Unable to parse batch date '$BATCH_DATE_RAW' from $BATCH_DATE_FILE. Adjust parse_batch_date() in common_lib.sh for your date format."
    fi
}

# ---------------------------------------------------------------------------
# Date condition helpers (all operate on BATCH_DATE, format YYYY-MM-DD)
# ---------------------------------------------------------------------------
is_friday() {
    [[ "$(date -d "$BATCH_DATE" +%u)" -eq 5 ]]
}

is_last_friday_of_month() {
    is_friday || return 1
    local next_week_month this_month
    this_month=$(date -d "$BATCH_DATE" +%m)
    next_week_month=$(date -d "$BATCH_DATE +7 days" +%m)
    [[ "$next_week_month" != "$this_month" ]]
}

is_last_day_of_month() {
    local this_month next_day_month
    this_month=$(date -d "$BATCH_DATE" +%m)
    next_day_month=$(date -d "$BATCH_DATE +1 day" +%m)
    [[ "$next_day_month" != "$this_month" ]]
}

# ---------------------------------------------------------------------------
# init_run_dirs <run_type>
#   Sets up the per-date log directory and the global LOG_FILE / RUN_FILE /
#   SUCCESS_MARKER / LOCK_FILE paths. Requires BATCH_DATE to be set already.
# ---------------------------------------------------------------------------
init_run_dirs() {
    local run_type="$1"
    LOG_DIR="${LOG_BASE_DIR}/${BATCH_DATE}"
    mkdir -p "$LOG_DIR" || die "Could not create log directory: $LOG_DIR"

    LOG_FILE="${LOG_DIR}/${run_type}_run.log"
    RUN_FILE="${LOG_DIR}/${run_type}_tasks_run.conf"
    SUCCESS_MARKER="${LOG_DIR}/${run_type}.SUCCESS"
    LOCK_FILE="${LOG_DIR}/${run_type}.lock"
}

# ---------------------------------------------------------------------------
# run_tasks <master_task_conf_file> <run_type>
#   The resumable task-runner engine. See header comment for behaviour.
# ---------------------------------------------------------------------------
run_tasks() {
    local master_file="$1"
    local run_type="$2"

    [[ -f "$master_file" ]] || die "Master task file not found: $master_file"

    # ---- single-instance lock for this run_type + date ----
    exec 9>"$LOCK_FILE"
    if ! flock -n 9; then
        die "Another instance of ${run_type} run for ${BATCH_DATE} is already in progress (lock: $LOCK_FILE)."
    fi

    # ---- already fully completed for this date? ----
    if [[ -f "$SUCCESS_MARKER" && "${FORCE_RERUN:-0}" != "1" ]]; then
        log "${run_type}: all tasks already completed successfully for batch date ${BATCH_DATE}."
        log "  (marker: $SUCCESS_MARKER). Use --force to re-run anyway."
        exit 0
    fi

    # ---- create the per-date working copy of the task list, if needed ----
    if [[ ! -f "$RUN_FILE" ]]; then
        cp "$master_file" "$RUN_FILE" || die "Could not create run file: $RUN_FILE"
        log "${run_type}: created new per-date task list: $RUN_FILE"
    else
        log "${run_type}: resuming existing per-date task list: $RUN_FILE"
    fi

    log "=============================================================="
    log "${run_type^^} run starting for batch date ${BATCH_DATE} (raw: ${BATCH_DATE_RAW})"
    log "Task list : $RUN_FILE"
    log "Log file  : $LOG_FILE"
    log "=============================================================="

    local total remaining
    total=$(grep -vE '^[[:space:]]*(#|$)' "$RUN_FILE" | wc -l)
    log "Tasks pending in run file: $total"

    local task_num=0
    local line trimmed rc

    while IFS= read -r line || [[ -n "$line" ]]; do
        trimmed=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

        # skip blanks and commented/completed lines
        [[ -z "$trimmed" ]] && continue
        [[ "$trimmed" == \#* ]] && continue

        task_num=$((task_num + 1))
        log "----> [$task_num/$total] START: $trimmed"

        # shellcheck disable=SC2086
        eval "$trimmed" >>"$LOG_FILE" 2>&1
        rc=$?

        if [[ $rc -ne 0 ]]; then
            log "----> [$task_num/$total] FAILED (exit code $rc): $trimmed"
            log "=============================================================="
            log "${run_type^^} run HALTED for batch date ${BATCH_DATE}."
            log "Completed successfully: $((task_num - 1)) task(s) above this line."
            log "Failed task            : $trimmed"
            log ""
            log "TO RESUME:"
            log "  1. Investigate/fix the cause of the failure."
            log "  2. Edit: $RUN_FILE"
            log "     - Put '#' in front of any task line already confirmed complete."
            log "     - Leave the failed task (and everything after it) uncommented."
            log "  3. Re-run this wrapper script. It will skip commented lines and"
            log "     resume from the next uncommented task."
            log "=============================================================="
            exit 1
        fi

        log "----> [$task_num/$total] SUCCESS: $trimmed"
    done <"$RUN_FILE"

    touch "$SUCCESS_MARKER"
    log "=============================================================="
    log "${run_type^^} run COMPLETED SUCCESSFULLY for batch date ${BATCH_DATE}. ($task_num task(s) executed)"
    log "=============================================================="
}
