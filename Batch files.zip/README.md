# OFSAA FCCM Batch Wrapper Scripts

## Files

| File | Purpose |
|---|---|
| `common_lib.sh` | Shared logic: logging, batch-date parsing, date conditions, resumable task-runner engine. Sourced by all four wrappers - do not run directly. |
| `run_daily.sh` | Runs `daily_tasks.conf`. No date condition - runs every day. |
| `run_weekly.sh` | Runs `weekly_tasks.conf`. Only runs when the batch date is a **Friday**. |
| `run_fourweekly.sh` | Runs `fourweekly_tasks.conf`. Only runs when the batch date is the **last Friday of the month**. |
| `run_monthly.sh` | Runs `monthly_tasks.conf`. Only runs when the batch date is the **last day of the month**. |
| `daily_tasks.conf`, `weekly_tasks.conf`, `fourweekly_tasks.conf`, `monthly_tasks.conf` | Master task lists - one shell command per line. This is where you add/remove/reorder tasks permanently. |

## One-time setup

1. Copy all files to a single directory on the server, e.g. `/u02/OFSAA/Scripts/batch_wrappers/`.
2. `chmod +x run_daily.sh run_weekly.sh run_fourweekly.sh run_monthly.sh common_lib.sh`
3. Confirm `/u02/OFSAA/Scripts/Batch_date/current_batch_date.txt` exists and contains a single date (any common format - `2026-07-18`, `18-JUL-2026`, `07/18/2026`, `20260718`, etc.). The scripts use `date -d` to parse it.
4. Confirm the user running the scripts can write to `/u02/OFSAA/scripts/logs`.

If your batch date file uses a genuinely ambiguous numeric format (e.g. `07/08/2026` could mean 7-Aug or 8-Jul depending on locale), edit `parse_batch_date()` in `common_lib.sh` to force the correct interpretation.

## Running

```
./run_daily.sh
./run_weekly.sh
./run_fourweekly.sh
./run_monthly.sh
```

Each script reads the batch date, checks its own condition (daily has none), and if applicable runs its task list in order. Wire these into cron/Control-M/whatever scheduler you like - they can simply run every day; the ones with a condition will self-skip when the date doesn't qualify and exit 0.

`--force` re-runs a task set even if it already completed successfully for the current batch date, e.g. `./run_weekly.sh --force`.

## Where logs and state live

Everything for a given batch date lands under:

```
/u02/OFSAA/scripts/logs/<batch_date>/
    daily_run.log
    daily_tasks_run.conf
    daily.SUCCESS            (only present once ALL daily tasks succeed)
    weekly_run.log
    weekly_tasks_run.conf
    weekly.SUCCESS
    ... (same pattern for fourweekly / monthly)
```

- `*_run.log` - full timestamped execution log (every task's START/SUCCESS/FAILED, plus the command's own stdout/stderr).
- `*_tasks_run.conf` - a **per-date working copy** of the matching master `.conf` file. This is the file you edit to resume after a failure (see below). It is created fresh the first time a given task set runs for a given batch date, and is left alone (never re-copied from the master) on every subsequent run for that same date - so your edits/comments persist across retries on the same day, but a brand-new date always starts from the clean master list.
- `*.SUCCESS` - an empty marker file written only when every task in that run finished with exit code 0. Its presence makes the script treat that day's run as already done and skip on any accidental re-trigger, unless you pass `--force`.

## How the fail-and-resume workflow works

1. The wrapper runs tasks from `<logdir>/<type>_tasks_run.conf` top to bottom.
2. The moment a task exits non-zero, the whole script stops immediately (no further tasks run). The log clearly states:
   - how many tasks completed successfully,
   - which task failed,
   - exactly which file to edit to resume.
3. To resume:
   - Investigate and fix whatever caused the failure.
   - Open `<logdir>/<type>_tasks_run.conf`.
   - Put a `#` in front of every line that is confirmed complete (the ones the log marked SUCCESS - and the failed one too, **only** if you've verified/fixed it manually and don't want the script to redo it).
   - Leave everything still-to-do uncommented.
   - Re-run the same wrapper script (`./run_weekly.sh`, etc.). It skips blank lines and `#` lines and resumes from the first uncommented line.
4. Once every line has been executed successfully (in one run or across several resumes), the script writes the `.SUCCESS` marker for that batch date and task type.

Important: this editing happens on the **per-date copy** (`*_tasks_run.conf`) inside the log folder, never on the master `.conf` file in the script directory. That keeps tomorrow's (or next week's/month's) run starting from your full, permanent task list.

## Adding/removing/reordering tasks permanently

Edit the relevant master file (`daily_tasks.conf`, `weekly_tasks.conf`, `fourweekly_tasks.conf`, or `monthly_tasks.conf`) - one command per line, `#` for comments. This only affects runs from that point forward; it has no effect on a batch date that has already generated its own per-date copy.

## Notes / assumptions

- "Last Friday of the month" and "last day of the month" are both computed purely from the date found in `current_batch_date.txt`, not the system clock - so you can safely test/replay with a different date in that file.
- Each run is protected by a `flock`-based lock file per batch-date/task-type, so two overlapping cron/scheduler triggers can't run the same task set concurrently.
- Tasks are executed with `eval`, so any valid shell command/arguments works, not just the `start_mantas.sh <id>` calls shown here.
