#!/usr/bin/env bash
###############################################################################
# run_daily.sh
# Runs the Daily OFSAA FCCM task set. No date condition - runs every day.
#
# Usage:
#   ./run_daily.sh            normal run (resumes automatically if a prior
#                              run for today's batch date failed partway)
#   ./run_daily.sh --force    re-run even if already marked SUCCESS for
#                              today's batch date
###############################################################################
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common_lib.sh
source "${SCRIPT_DIR}/common_lib.sh"

MASTER_TASK_FILE="${SCRIPT_DIR}/daily_tasks.conf"
RUN_TYPE="daily"

FORCE_RERUN=0
[[ "${1:-}" == "--force" ]] && FORCE_RERUN=1

parse_batch_date
init_run_dirs "$RUN_TYPE"

log "Daily run: no date condition to check - proceeding for batch date ${BATCH_DATE}."

run_tasks "$MASTER_TASK_FILE" "$RUN_TYPE"
