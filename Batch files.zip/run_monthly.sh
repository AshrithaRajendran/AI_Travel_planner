#!/usr/bin/env bash
###############################################################################
# run_monthly.sh
# Runs the Monthly OFSAA FCCM task set.
# Condition: only runs when the batch date (from current_batch_date.txt) is
# the last calendar day of the month. Any other day, it logs a skip message
# and exits 0.
#
# Usage:
#   ./run_monthly.sh            normal run
#   ./run_monthly.sh --force    re-run even if already marked SUCCESS for
#                               this batch date
###############################################################################
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common_lib.sh
source "${SCRIPT_DIR}/common_lib.sh"

MASTER_TASK_FILE="${SCRIPT_DIR}/monthly_tasks.conf"
RUN_TYPE="monthly"

FORCE_RERUN=0
[[ "${1:-}" == "--force" ]] && FORCE_RERUN=1

parse_batch_date
init_run_dirs "$RUN_TYPE"

if ! is_last_day_of_month; then
    log "Monthly run: batch date ${BATCH_DATE} is not the last day of the month. Skipping (nothing to do)."
    exit 0
fi

log "Monthly run: batch date ${BATCH_DATE} is the last day of the month - condition met, proceeding."

run_tasks "$MASTER_TASK_FILE" "$RUN_TYPE"
