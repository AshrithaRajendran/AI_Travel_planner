#!/usr/bin/env bash
###############################################################################
# run_fourweekly.sh
# Runs the FourWeekly OFSAA FCCM task set.
# Condition: only runs when the batch date (from current_batch_date.txt) is
# the LAST Friday of the month. Any other day, it logs a skip message and
# exits 0.
#
# Usage:
#   ./run_fourweekly.sh            normal run
#   ./run_fourweekly.sh --force    re-run even if already marked SUCCESS for
#                                  this batch date
###############################################################################
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common_lib.sh
source "${SCRIPT_DIR}/common_lib.sh"

MASTER_TASK_FILE="${SCRIPT_DIR}/fourweekly_tasks.conf"
RUN_TYPE="fourweekly"

FORCE_RERUN=0
[[ "${1:-}" == "--force" ]] && FORCE_RERUN=1

parse_batch_date
init_run_dirs "$RUN_TYPE"

if ! is_last_friday_of_month; then
    log "FourWeekly run: batch date ${BATCH_DATE} is not the last Friday of the month. Skipping (nothing to do)."
    exit 0
fi

log "FourWeekly run: batch date ${BATCH_DATE} is the last Friday of the month - condition met, proceeding."

run_tasks "$MASTER_TASK_FILE" "$RUN_TYPE"
