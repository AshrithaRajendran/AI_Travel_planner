#!/usr/bin/env bash
###############################################################################
# run_weekly.sh
# Runs the Weekly OFSAA FCCM task set.
# Condition: only runs when the batch date (from current_batch_date.txt) is
# a Friday. Any other day, it logs a skip message and exits 0.
#
# Usage:
#   ./run_weekly.sh            normal run
#   ./run_weekly.sh --force    re-run even if already marked SUCCESS for
#                              this batch date
###############################################################################
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./common_lib.sh
source "${SCRIPT_DIR}/common_lib.sh"

MASTER_TASK_FILE="${SCRIPT_DIR}/weekly_tasks.conf"
RUN_TYPE="weekly"

FORCE_RERUN=0
[[ "${1:-}" == "--force" ]] && FORCE_RERUN=1

parse_batch_date
init_run_dirs "$RUN_TYPE"

if ! is_friday; then
    log "Weekly run: batch date ${BATCH_DATE} is not a Friday. Skipping (nothing to do)."
    exit 0
fi

log "Weekly run: batch date ${BATCH_DATE} is a Friday - condition met, proceeding."

run_tasks "$MASTER_TASK_FILE" "$RUN_TYPE"
